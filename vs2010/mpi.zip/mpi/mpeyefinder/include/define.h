#ifndef __define_H__
#define __define_H__

#ifdef WIN32
// hrrrngh?
//#define notWindows

#define PrintEyeBox
#endif // WIN32

#endif //__define_H__